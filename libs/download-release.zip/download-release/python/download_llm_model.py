import os
import re
from huggingface_hub import hf_hub_download

from huggingface_hub import HfFileSystem

class ModelFiles:
    def __init__(self):
        self.model_file_type = "pytorch"
        self.files_array = []


def analyze_repo(repo_id: str):
    result_str = "" 
    model_files = ModelFiles() 
    fs = HfFileSystem()
    try:
        repo_content = fs.ls(repo_id[0], detail=False)

        if len(repo_content) == 0:
            print("empty")
            return "empty"
            

        for each_file in repo_content:
            if each_file.endswith('.gguf'):
                model_files.files_array.append(each_file.split('/')[-1])
                #model_files.files_array.append(each_file)

        gguf_len = len(model_files.files_array) 

        if gguf_len == 1:
            model_files.mode_file_type = "gguf"
        elif gguf_len > 1:
            model_files.model_file_type = "mul_gguf"
    except:
        model_files.model_file_type = "model_not_exist"

    result_str = model_files.model_file_type

    for model_file in model_files.files_array:
        result_str += ":"
        result_str += model_file

    print(result_str)
    return result_str 

def get_model_file_size(repo_model_file: str):
    model_size = 0 
    fs = HfFileSystem()
    try:
        model_content = fs.ls(repo_model_file[0], detail=True)
        if model_content == None or len(model_content) == 0:
            print(-1)
            return -1
        model_size = model_content[0]['size']
        if model_size == None or model_size == 0:
            print(-2)
            return -2
    except:
        print(-3)
        return -3

    print(model_size)
    return model_size

def download_customerized_model_windows(repo_id: str, model_name: str, papersgpt_version: str):
    home_path = os.path.expanduser('~')
    project_dir = "." + papersgpt_version[0]
    if papersgpt_version[0] == "llm-server" or papersgpt_version[0] == "embedding-server":
        project_dir = ".papersgpt"
    print("llm-server after....")
    print(project_dir)
    model_dir = home_path + "\\" + project_dir + "\\local-models\\"
    if papersgpt_version[0] == "llm-server":
        model_dir = model_dir + "bin"
    elif papersgpt_version[0] == "embedding-server":
        model_dir = home_path + "\\" + project_dir
    else:
        model_dir = model_dir + repo_id[0]
    print(model_dir)
    model_file_download_sign = model_name[0] + ".download.success"
    print(model_file_download_sign)
    download_status_file = model_dir + "\\" + model_file_download_sign 

    print(model_dir)

    print(model_file_download_sign)

    is_download_exist = os.path.isfile(download_status_file)
    if is_download_exist:
        os.remove(download_status_file)
    
    print("----hf_hub_download before----")
    print(repo_id[0])
    print(model_name[0])
    print(model_dir)

    try:
        # download 
        hf_hub_download(repo_id=repo_id[0],
                filename= model_name[0],
                local_dir=model_dir)

    except:
        print("hf download error!")
        return


    # checksum 
    # move 
    #shutil()
    
    model_file_path = model_dir + "\\" + model_name[0]

    is_file_exist = os.path.isfile(model_file_path)
    if not is_file_exist:
        print("model not download successful!")
        return

    with open(download_status_file, "w") as r:
        r.write('download.success')



def download_customerized_model(repo_id: str, model_name: str, awamind_version: str):
    home_path = os.path.expanduser('~')
    model_dir = home_path + "/Documents/" + awamind_version[0] + "/local-models/" + repo_id[0]
    model_file_download_sign = model_name[0] + ".download.success"
    download_status_file = home_path + "/Documents/" + awamind_version[0] + "/local-models/" + repo_id[0] + "/" + model_file_download_sign 

    is_download_exist = os.path.isfile(download_status_file)
    if is_download_exist:
        os.remove(download_status_file)
    
    try:
        # download 
        hf_hub_download(repo_id=repo_id[0],
                filename= model_name[0],
                local_dir=model_dir)

    except:
        print("hf download error!")
        return


    # checksum 
    # move 
    #shutil()
    
    model_file_path = model_dir + "/" + model_name[0]

    is_file_exist = os.path.isfile(model_file_path)
    if not is_file_exist:
        print("model not download successful!")
        return

    with open(download_status_file, "w") as r:
        r.write('download.success')

if __name__ == "__main__":
    #print(analyze_repo("openbmb/MiniCPM-Llama3-V-2_5-gguf"))
    #print(analyze_repo("cognitivecomputations/dolphin-2.9-llama3-8b").model_file_type)
    #print("file_size is", file_size)

    '''
    model_file_size = get_model_file_size('openbmb/MiniCPM-Llama3-V-2_5-gguf/ggml-model-Q2_K.gguf')
    print('model_file_size is', model_file_size)
    model_files = analyze_repo('openbmb/MiniCPM-Llama3-V-2_5-gguf')
    print('model_files is', model_files)
    '''
    download_customerized_model_windows("unsloth/Qwen3-0.6B-GGUF", "Qwen3-0.6B-Q2_K.gguf", "papersgpt")


